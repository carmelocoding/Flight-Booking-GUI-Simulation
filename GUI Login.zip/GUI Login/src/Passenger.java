
public class Passenger
{
    //passenger variables
    public String name;
    public String gender;
    public boolean Over18;

    Passenger()
    {
        //default constructor
        name = "Unknown";
        gender = "Unknown";
        Over18 = true;
    }

    Passenger(String newName, String newGender, boolean newOver18)
    {
        //constructor with passenger parameters
        name = newName;
        gender = newGender;
        Over18 = newOver18;
        //stores parameters into variables that I can use
    }
}
