public class Main
{
    //GUI constructor contains the method CreateFrame1, which has createframe2 inside it, which has createframe3 inside it, so this is the only line needed
    //I remember you saying you want a clean main.. I can see why you did. Looks clean

    public static void main(String[] args)
    {
        new GUI();
    }
    
}
