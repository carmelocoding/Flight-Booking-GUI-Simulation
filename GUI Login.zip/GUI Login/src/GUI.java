import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.SQLOutput;
import java.util.Random;
//required imports

public class GUI implements ActionListener {
    //allows buttons to do something when clicked

    //frame 1 (Declared here as these frame aspects are used outside their respective methods
    private static JFrame frame;
    private static JLabel success;
    private static JLabel Etnad;
    private static JPanel panel;
    private static JButton loginButton;

    private static JTextField userText;
    private static JPasswordField passwordText;

    public static String username;
    public static String passcode;

    //frame 2 & 3
    private static JFrame frame2;
    private static JFrame frame3;

    //needed here as they are used in the button method and create2Frame

    String[] Cities = {"Rome, Italy", "Paris, France", "London, England", "Toronto, Canada", "Los Angeles, USA", "Tokyo, Japan", "Amsterdam, Netherlands", "Hong Kong, China", "Bangkok, Thailand", "Madrid, Spain", "Dubai, United Arab Emirates", "Istanbul, Turkey"};

    String [] Genders = {"Male", "Female", "Other"};

    String[] Classes = {"First","Business","Economy"};

    String [] Sections = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N"};

    Integer[] numPassengers = {1,2,3,4};

    //declaring and initializing the combo boxes, checkboxes and text fields on frame 2

    //combo box will contain all the options states within the array "Genders" based on how i declared it.
    //combo box's options will be whatever the array called contains
    JComboBox passenger1Gender = new JComboBox(Genders);
    JComboBox passenger2Gender = new JComboBox(Genders);
    JComboBox passenger3Gender = new JComboBox(Genders);
    JComboBox passenger4Gender = new JComboBox(Genders);

    JComboBox classComboBox = new JComboBox(Classes);
    JComboBox fromComboBox = new JComboBox(Cities);
    JComboBox toComboBox = new JComboBox(Cities);
    JComboBox numOfPassengersComboBox = new JComboBox(numPassengers);
    JComboBox seatSectionComboBox = new JComboBox(Sections);


    //Creates a small message that says whatevers in the brackets and a little box that you can check and uncheck
    // Usually for yes or no things
    JCheckBox passenger1Age = new JCheckBox("Over 18?");
    JCheckBox passenger2Age = new JCheckBox("Over 18?");
    JCheckBox passenger3Age = new JCheckBox("Over 18?");
    JCheckBox passenger4Age = new JCheckBox("Over 18?");

    JTextField fullNameTextField1 = new JTextField("Passenger 1");
    JTextField fullNameTextField2 = new JTextField("Passenger 2");
    JTextField fullNameTextField3 = new JTextField("Passenger 3");
    JTextField fullNameTextField4 = new JTextField("Passenger 4");

    //shows proper format for the date
    JTextField departureTextField = new JTextField("dd // mm // yyyy");


    JTextField tripLengthTextField = new JTextField("(Number of days)");

    //variables for flight and passenger objects
    String departureDate;
    int tripLength;
    String flightClass;
    String departingFrom;
    String departingTo;
    int numberOfPassengers;
    String seatSection;

    String passenger1Name;
    String passenger2Name;
    String passenger3Name;
    String passenger4Name;

    boolean isPassenger1Over18;
    boolean isPassenger2Over18;
    boolean isPassenger3Over18;
    boolean isPassenger4Over18;

    String genderPassenger1;
    String genderPassenger2;
    String genderPassenger3;
    String genderPassenger4;

    //creating objects here to be used later (multiple methods)
    Flight flight = new Flight();

    Passenger passenger1 = new Passenger();
    Passenger passenger2 = new Passenger();
    Passenger passenger3 = new Passenger();
    Passenger passenger4 = new Passenger();

    JLabel printSuccess;

    // frame 4
    JButton payButton;
    private static JFrame frame4;

    //GUI constructor, calls method which also has frame2creator called inside it which has frame3creator called inside of frame2creator
    public GUI()
    {
        Frame1Creator();
    }


    public void Frame1Creator()
    {
        //simple way to allow user to create username and password. I would've made it so that the password has to be a certain length, but i don't have the time to figure that out
        username = JOptionPane.showInputDialog("Create your username.");
        passcode = JOptionPane.showInputDialog("Create your password.");

        //subtitle for GUI
        frame = new JFrame("Etnad Airlines Login");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //set layout null allows me to move GUI aspects around freely
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(10, 200, 200));

        //main title for GUI
        Etnad = new JLabel("Etnad Airways");
        Etnad.setFont(new Font("Consolas", Font.BOLD, 18));
        Etnad.setBounds(10, 10, 200, 35);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Consolas", Font.BOLD, 16));
        userLabel.setBounds(10, 70, 80, 25);

        //allows user to enter password to login
        userText = new JTextField(20);
        userText.setBounds(100, 70, 165, 25);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Consolas", Font.BOLD, 16));
        passLabel.setBounds(10, 100, 80, 25);

        //same as JTextField but hides text
        passwordText = new JPasswordField(20);
        passwordText.setBounds(100, 100, 165, 25);

        //addActionListener allows button to look for a certain method once the button is pressed, in this case: loginClick()
        loginButton = new JButton("Login");
        loginButton.setBounds(10, 150, 80, 25);
        loginButton.addActionListener(this:: loginClick);

        //keep text blank for now, later will show failure IF they fail to sign in
        success = new JLabel("");
        success.setFont(new Font("Consolas", Font.BOLD, 14));
        success.setBounds(10, 210, 300, 25);

        //bit of ascii art
        JLabel Ascii1 = new JLabel(" __|__");
        Ascii1.setFont(new Font("Consolas", Font.BOLD, 14));
        Ascii1.setBounds(255, 0, 200, 25);

        JLabel Ascii2 = new JLabel("|--o--o--(_)--o--o--|");
        Ascii2.setFont(new Font("Consolas", Font.BOLD, 14));
        Ascii2.setBounds(199, 20, 200, 25);

        //adding elements to the panel, which is on the frame
        frame.add(panel);
        panel.add(Etnad);
        panel.add(userLabel);
        panel.add(userText);
        panel.add(passLabel);
        panel.add(passwordText);
        panel.add(loginButton);
        panel.add(success);
        panel.add(Ascii1);
        panel.add(Ascii2);

        //frame is now visible
        frame.setVisible(true);

    }

    public void loginClick(ActionEvent e)
    {
        //this will run everytime login is clicked

        //strings are equal to whatever is entered
        String user = userText.getText();
        String password = passwordText.getText();

        if (user.equals(username) && password.equals(passcode))
        {
            //tells you that you properly signed in, then hides the first frame, and shows the second one
            JOptionPane.showMessageDialog(null,"Login success.");
            frame.setVisible(false);
            Frame2Creator();
        }
        else
        {
            //in case of failure
            success.setText("Login failure.");
        }
    }

    public void Frame2Creator()
    {
        //create frame2
        frame2 = new JFrame("Flight Information");
        frame2.setSize(750,500);
        frame2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //create panel and add it to frame
        JPanel panel2 = new JPanel();
        panel2.setLayout(null);
        panel2.setBackground(new Color(200,100,250));
        frame2.add(panel2);

        //creates and sets the location of the label, also creates the border of this component
        JLabel titleLabel = new JLabel("  Etnad Airways Flight Reservation");
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 26));
        Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
        titleLabel.setBorder(border);
        titleLabel.setBounds(450,25,410,50);

        //creates image/logo
        BufferedImage myPicture = null;
        try
        {
            //searches src file for EtnadAirplane.png
            myPicture = ImageIO.read(new File("src/EtnadAirplane.png"));

        }
        catch (IOException e)
        {
            //catches possible error with photo read
            e.printStackTrace();
        }

        //adds photo to label
        JLabel logoLabel = new JLabel(new ImageIcon(myPicture));

        Border border1 = BorderFactory.createLineBorder(Color.BLACK, 4);
        logoLabel.setBorder(border1);
        logoLabel.setBounds(980,0,300,140);

        JLabel subLabel1 = new JLabel(" Flight Information:");
        subLabel1.setFont(new Font("Consolas", Font.BOLD, 18));
        subLabel1.setBounds(35,60,230,35);

        //label that allows outline, makes component placement easier
        // If you add a component to this large label, the new reference point for 0,0 is the top left of this outline

        JLabel flightOutline = new JLabel();
        flightOutline.setBounds(20,90,415,550);
        Border border3 =  BorderFactory.createLineBorder(Color.BLACK, 5);
        flightOutline.setBorder(border3);

        //many labels, text fields and others are created here, i've already explained how most of them worked

        //creates a label and sets its text to text in brackets. Then changes font and later adds it to the flight outline
        JLabel departureDateLabel = new JLabel(" Departure date: ");
        departureDateLabel.setFont(new Font("Times New Roman",Font.BOLD,18));
        departureDateLabel.setBounds(20,10,200,30);

        //it's already been declared & initialized earlier, sets font and location/size
        departureTextField.setFont(new Font("Times New Roman",Font.BOLD,14));
        departureTextField.setBounds(170,10,150,30);

        JLabel tripLengthLabel = new JLabel(" Trip length: ");
        tripLengthLabel.setFont(new Font("Times New Roman",Font.BOLD,18));
        tripLengthLabel.setBounds(20,90,200,30);

        tripLengthTextField.setFont(new Font("Times New Roman",Font.BOLD,14));
        tripLengthTextField.setBounds(170,90,150,30);

        JLabel classLabel = new JLabel(" Flight Class: ");
        classLabel.setFont(new Font("Times New Roman",Font.BOLD,18));
        classLabel.setBounds(20,170,150,30);

        classComboBox.setBounds(170,175,150,30);
        classComboBox.setFont(new Font("Consolas",Font.BOLD,14));

        JLabel fromLabel = new JLabel(" Departing from: ");
        fromLabel.setFont(new Font("Times New Roman",Font.BOLD,18));
        fromLabel.setBounds(20,250,150,30);

        fromComboBox.setBounds(170,255,215,30);
        fromComboBox.setFont(new Font("Consolas",Font.BOLD,12));

        JLabel toLabel = new JLabel(" Departing to: ");
        toLabel.setFont(new Font("Times New Roman",Font.BOLD,18));
        toLabel.setBounds(20,330,150,30);


        toComboBox.setBounds(170,335,215,30);
        toComboBox.setFont(new Font("Consolas",Font.BOLD,12));

        JLabel passengerAmountLabel = new JLabel(" # of passengers: ");
        passengerAmountLabel.setFont(new Font("Times New Roman",Font.BOLD,18));
        passengerAmountLabel.setBounds(20,410,150,30);

        numOfPassengersComboBox.setBounds(170,415,100,30);
        numOfPassengersComboBox.setFont(new Font("Consolas",Font.BOLD,12));

        JLabel seatSectionLabel = new JLabel(" Seat section: ");
        seatSectionLabel.setFont(new Font("Times New Roman",Font.BOLD,18));
        seatSectionLabel.setBounds(20,490,150,30);

        seatSectionComboBox.setBounds(170,495,100,30);
        seatSectionComboBox.setFont(new Font("Consolas",Font.BOLD,12));

        //adds all the flight details required to the flight outline, which is then added to the panel
        flightOutline.add(departureDateLabel);
        flightOutline.add(departureTextField);
        flightOutline.add(tripLengthLabel);
        flightOutline.add(tripLengthTextField);
        flightOutline.add(classLabel);
        flightOutline.add(classComboBox);
        flightOutline.add(fromLabel);
        flightOutline.add(fromComboBox);
        flightOutline.add(toLabel);
        flightOutline.add(toComboBox);
        flightOutline.add(passengerAmountLabel);
        flightOutline.add(numOfPassengersComboBox);
        flightOutline.add(seatSectionLabel);
        flightOutline.add(seatSectionComboBox);

        //passenger info portion. Shows a total of 4 possible passengers and all required info from them
        //but will only print tickets for the amount of tickets requested going from 1-4
        //most of the components in here will already have been declared for usage reasons
        JLabel subLabel2 = new JLabel(" Passenger Information:");
        subLabel2.setFont(new Font("Consolas", Font.BOLD, 18));
        subLabel2.setBounds(475,140,250,35);

        JLabel passengerOutline = new JLabel();
        passengerOutline.setBounds(475,175,750,375);
        Border border4 =  BorderFactory.createLineBorder(Color.BLACK, 5);
        passengerOutline.setBorder(border4);

        //names
        JLabel fullNameLabel = new JLabel("Full Name (Last name, first name) ");
        fullNameLabel.setFont(new Font("Times New Roman",Font.BOLD,16));
        fullNameLabel.setBounds(30,25,250,30);

        fullNameTextField1.setFont(new Font("Times New Roman",Font.BOLD,14));
        fullNameTextField1.setBounds(40,75,250,30);

        fullNameTextField2.setFont(new Font("Times New Roman",Font.BOLD,14));
        fullNameTextField2.setBounds(40,150,250,30);

        fullNameTextField3.setFont(new Font("Times New Roman",Font.BOLD,14));
        fullNameTextField3.setBounds(40,225,250,30);

        fullNameTextField4.setFont(new Font("Times New Roman",Font.BOLD,14));
        fullNameTextField4.setBounds(40,300,250,30);

        //ages of passengers
        JLabel ageLabel = new JLabel("Age Range");
        ageLabel.setFont(new Font("Times New Roman",Font.BOLD,16));
        ageLabel.setBounds(400,25,175,30);

        passenger1Age.setBounds(400,75,100,30);

        passenger2Age.setBounds(400,150,100,30);

        passenger3Age.setBounds(400,225,100,30);

        passenger4Age.setBounds(400,300,100,30);

        //passenger genders (this is necessary for person - ticket confirmation in real life.. i think?
        JLabel genderLabel = new JLabel("Gender");
        genderLabel.setFont(new Font("Times New Roman",Font.BOLD,16));
        genderLabel.setBounds(570,25,200,30);

        passenger1Gender.setFont(new Font("Consolas",Font.BOLD,12));
        passenger1Gender.setBounds(570,75,100,30);

        passenger2Gender.setFont(new Font("Consolas",Font.BOLD,12));
        passenger2Gender.setBounds(570,150,100,30);

        passenger3Gender.setFont(new Font("Consolas",Font.BOLD,12));
        passenger3Gender.setBounds(570,225,100,30);

        passenger4Gender.setFont(new Font("Consolas",Font.BOLD,12));
        passenger4Gender.setBounds(570,300,100,30);

        //whole lotta adding to the outline
        passengerOutline.add(fullNameLabel);
        passengerOutline.add(fullNameTextField1);
        passengerOutline.add(fullNameTextField2);
        passengerOutline.add(fullNameTextField3);
        passengerOutline.add(fullNameTextField4);
        passengerOutline.add(ageLabel);
        passengerOutline.add(passenger1Age);
        passengerOutline.add(passenger2Age);
        passengerOutline.add(passenger3Age);
        passengerOutline.add(passenger4Age);
        passengerOutline.add(genderLabel);
        passengerOutline.add(passenger1Gender);
        passengerOutline.add(passenger2Gender);
        passengerOutline.add(passenger3Gender);
        passengerOutline.add(passenger4Gender);

        //button which allows you to submit/save entered info
        JButton submit = new JButton("Submit Information");
        submit.setBounds(1050,580,180,45);
        submit.setFont(new Font ("Consolas", Font.BOLD, 12));
        submit.addActionListener(this:: submitClick);

        //adding components to panel
        //this looks much cleaner then adding all those above components here. More organized IMO (in my opinion if u didn't know)
        panel2.add(titleLabel);
        panel2.add(logoLabel);
        panel2.add(subLabel1);
        panel2.add(subLabel2);
        panel2.add(flightOutline);
        panel2.add(passengerOutline);
        panel2.add(submit);


        frame2.setVisible(true);

    }

    //I'll be honest I don't fully understand how Override works, but I think it means that this method declaration overrules any previous one?
    @Override
    public void actionPerformed(ActionEvent e)
    {
        //no button ever makes this happen
        System.out.println("\n Should be null.");

    }
    public void submitClick(ActionEvent e)
    {
        departingFrom =  Cities [fromComboBox.getSelectedIndex()];
        departingTo = Cities [toComboBox.getSelectedIndex()];

        if(departingFrom.equals(departingTo))
        {
            //stopping a user error, obviously you wouldnt want to fly to and from the same city
            JOptionPane.showMessageDialog(null,"You can't fly to and from the same city.");
        }

        if(!departingFrom.equals(departingTo))

        {
            //trip details stored, the combo boxes searches through the array and finds what was selected
            // Parse int is used because its meant to read a string, not a int. I want an int tho, so here we are
            departureDate = departureTextField.getText();
            tripLength = Integer.parseInt(tripLengthTextField.getText());
            flightClass = Classes[classComboBox.getSelectedIndex()];
            departingFrom = Cities[fromComboBox.getSelectedIndex()];
            departingTo = Cities[toComboBox.getSelectedIndex()];
            numberOfPassengers = numPassengers[numOfPassengersComboBox.getSelectedIndex()];
            seatSection = Sections[seatSectionComboBox.getSelectedIndex()];

            //flight object initialized
            flight = new Flight(departureDate, tripLength, flightClass, departingFrom, departingTo, numberOfPassengers, seatSection);

            //passenger details stored
            passenger1Name = fullNameTextField1.getText();
            passenger2Name = fullNameTextField2.getText();
            passenger3Name = fullNameTextField3.getText();
            passenger4Name = fullNameTextField4.getText();

            genderPassenger1 = Genders[passenger1Gender.getSelectedIndex()];
            genderPassenger2 = Genders[passenger2Gender.getSelectedIndex()];
            genderPassenger3 = Genders[passenger3Gender.getSelectedIndex()];
            genderPassenger4 = Genders[passenger4Gender.getSelectedIndex()];

            //looks to find whether the checkboxes are selected
            isPassenger1Over18 = passenger1Age.isSelected();
            isPassenger2Over18 = passenger2Age.isSelected();
            isPassenger3Over18 = passenger3Age.isSelected();
            isPassenger4Over18 = passenger4Age.isSelected();

            //passenger objects
            passenger1 = new Passenger(passenger1Name, genderPassenger1, isPassenger1Over18);
            passenger2 = new Passenger(passenger2Name, genderPassenger2, isPassenger2Over18);
            passenger3 = new Passenger(passenger3Name, genderPassenger3, isPassenger3Over18);
            passenger4 = new Passenger(passenger4Name, genderPassenger4, isPassenger4Over18);

            //hides frame 2 and moves onto the frame 3
            frame2.setVisible(false);
            Frame3Creator();
        }
    }


    public void Frame3Creator()
    {

        //create frame 3
        frame3 = new JFrame("Tickets");
        frame3.setSize(750, 500);
        frame3.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //this is where the Random class is utilized. Just to give the ticket a seat number. Randomizes between 0 and 20 (21-1)
        Random rand = new Random();
        int upperBound = 21;
        int seatNumber1 = rand.nextInt(upperBound);

        //create panel and add it to frame
        JPanel panel3 = new JPanel();
        panel3.setLayout(null);
        panel3.setBackground(new Color(100, 150, 50));
        frame3.add(panel3);

        JLabel titleLabel2 = new JLabel("  Tickets Requested");
        titleLabel2.setFont(new Font("Times New Roman", Font.BOLD, 24));
        Border border = BorderFactory.createLineBorder(Color.BLACK, 3); // sets the border of this component
        titleLabel2.setBorder(border);
        titleLabel2.setBounds(540, 15, 230, 35);

        //creates image/logo
        BufferedImage myPicture1 = null;
        try
        {
            //searches src file for EtnadAirplane.png
            myPicture1 = ImageIO.read(new File("src/EtnadAirplane.png"));
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        //adds photo to label
        JLabel logoLabel = new JLabel(new ImageIcon(myPicture1));
        Border borderPicture = BorderFactory.createLineBorder(Color.BLACK, 4);
        logoLabel.setBorder(borderPicture);
        logoLabel.setBounds(980, 0, 300, 140);

        //ticket 1 (I'll explain 1, they are all the same except with specifications for each passenger.)
        //Creates a bunch of labels containing informtion on each person, but in a ticket format, even with created barcodes (all different btw)
        //some if statements in there based on possible options certain aspects of each passenger has, like gender
        JLabel subLabel1 = new JLabel(" Ticket 1:");
        subLabel1.setFont(new Font("Consolas", Font.BOLD, 18));
        subLabel1.setBounds(35, 120, 230, 35);

        JLabel ticket1Outline = new JLabel();
        ticket1Outline.setBounds(20, 150, 500, 200);
        Border borderTicket1 = BorderFactory.createLineBorder(Color.BLACK, 5);
        ticket1Outline.setBorder(borderTicket1);

        JLabel ticketLogoLabel1 = new JLabel("Etnad Airways");
        ticketLogoLabel1.setFont(new Font("Consolas", Font.BOLD, 18));
        ticketLogoLabel1.setBounds(15,10,300,35);

        JLabel passengerNameLabel1 = new JLabel("Name: " + passenger1.name);
        passengerNameLabel1.setFont(new Font("Consolas", Font.BOLD, 12));
        passengerNameLabel1.setBounds(15,40,250,35);

        JLabel flightClassLabel1 = new JLabel("Class: " + flight.flightClass1);
        flightClassLabel1.setFont(new Font("Consolas", Font.BOLD, 12));
        flightClassLabel1.setBounds(15,70,150,35);

        JLabel flyingFromLabel1 = new JLabel("From: " + flight.departingFrom1);
        flyingFromLabel1.setFont(new Font("Consolas", Font.BOLD, 12));
        flyingFromLabel1.setBounds(15,100,200,35);

        JLabel flyingToLabel1 = new JLabel("To: " + flight.departingTo1);
        flyingToLabel1.setFont(new Font("Consolas", Font.BOLD, 12));
        flyingToLabel1.setBounds(15,130,200,35);

        JLabel gender1 = new JLabel();
        gender1.setFont(new Font("Consolas", Font.BOLD, 12));
        gender1.setBounds(15,160,200,35);

        if (passenger1.gender == "Male")
        {
            gender1.setText("Gender: M");
        }
        else if (passenger1.gender == "Female")
        {
            gender1.setText("Gender: F");
        }
        else
        {
            gender1.setText("Gender: O");
        }

        JLabel adultOrChild1 = new JLabel();
        adultOrChild1.setFont(new Font("Consolas", Font.BOLD, 12));
        adultOrChild1.setBounds(400,5,200,35);

            if (passenger1.Over18)
            {
                adultOrChild1.setText("Adult Ticket");
            }
            else
            {
                adultOrChild1.setText("Child Ticket");
            }


        JLabel barCode1 = new JLabel("|| |||||| ||||| |||||||");
        barCode1.setFont(new Font("Consolas", Font.BOLD, 12));
        barCode1.setBounds(330,160,300,35);

        JLabel barCode1b = new JLabel("| |||| || |||| |||| |");
        barCode1b.setFont(new Font("Consolas", Font.BOLD, 12));
        barCode1b.setBounds(328,160,300,35);

        JLabel seatLabel1 = new JLabel("Seat: " + flight.seatSection1 + seatNumber1);
        seatLabel1.setFont(new Font("Consolas", Font.BOLD, 12));
        seatLabel1.setBounds(250,40,200,35);

        JLabel departureDate1 = new JLabel("Departure date: " + flight.departureDate1);
        departureDate1.setFont(new Font("Consolas", Font.BOLD, 12));
        departureDate1.setBounds(250,70,200,35);

        //ticket 2
        JLabel subLabel2 = new JLabel(" Ticket 2:");
        subLabel2.setFont(new Font("Consolas", Font.BOLD, 18));
        subLabel2.setBounds(35, 380, 230, 35);

        JLabel ticket2Outline = new JLabel();
        ticket2Outline.setBounds(20, 420, 500, 200);
        Border borderTicket2 = BorderFactory.createLineBorder(Color.BLACK, 5);
        ticket2Outline.setBorder(borderTicket2);

        JLabel ticketLogoLabel2 = new JLabel("Etnad Airways");
        ticketLogoLabel2.setFont(new Font("Consolas", Font.BOLD, 18));
        ticketLogoLabel2.setBounds(15,10,150,35);

        JLabel passengerNameLabel2 = new JLabel("Name: " + passenger2.name);
        passengerNameLabel2.setFont(new Font("Consolas", Font.BOLD, 12));
        passengerNameLabel2.setBounds(15,40,250,35);

        JLabel flightClassLabel2 = new JLabel("Class: " + flight.flightClass1);
        flightClassLabel2.setFont(new Font("Consolas", Font.BOLD, 12));
        flightClassLabel2.setBounds(15,70,150,35);

        JLabel flyingFromLabel2 = new JLabel("From: " + flight.departingFrom1);
        flyingFromLabel2.setFont(new Font("Consolas", Font.BOLD, 12));
        flyingFromLabel2.setBounds(15,100,200,35);

        JLabel flyingToLabel2 = new JLabel("To: " + flight.departingTo1);
        flyingToLabel2.setFont(new Font("Consolas", Font.BOLD, 12));
        flyingToLabel2.setBounds(15,130,200,35);

        JLabel gender2 = new JLabel();
        gender2.setFont(new Font("Consolas", Font.BOLD, 12));
        gender2.setBounds(15,160,200,35);

        if (passenger2.gender == "Male")
        {
            gender2.setText("Gender: M");
        }
        else if (passenger2.gender == "Female")
        {
            gender2.setText("Gender: F");
        }
        else
        {
            gender2.setText("Gender: O");
        }

        JLabel adultOrChild2 = new JLabel();
        adultOrChild2.setFont(new Font("Consolas", Font.BOLD, 12));
        adultOrChild2.setBounds(400,5,200,35);

        if (passenger2.Over18)
        {
            adultOrChild2.setText("Adult Ticket");
        }
        else
        {
            adultOrChild2.setText("Child Ticket");
        }

        JLabel barCode2 = new JLabel("|| |||||| ||||||| ||||");
        barCode2.setFont(new Font("Consolas", Font.BOLD, 12));
        barCode2.setBounds(330,160,300,35);

        JLabel barCode2b = new JLabel("||| |||| || | |||||||");
        barCode2b.setFont(new Font("Consolas", Font.BOLD, 12));
        barCode2b.setBounds(328,160,300,35);

        JLabel seatLabel2 = new JLabel("Seat: " + flight.seatSection1 + (seatNumber1+1));
        seatLabel2.setFont(new Font("Consolas", Font.BOLD, 12));
        seatLabel2.setBounds(250,40,200,35);

        JLabel departureDate2 = new JLabel("Departure date: " + flight.departureDate1);
        departureDate2.setFont(new Font("Consolas", Font.BOLD, 12));
        departureDate2.setBounds(250,70,200,35);

        //ticket 3
        JLabel subLabel3 = new JLabel(" Ticket 3:");
        subLabel3.setFont(new Font("Consolas", Font.BOLD, 18));
        subLabel3.setBounds(550, 120, 230, 35);

        JLabel ticket3Outline = new JLabel();
        ticket3Outline.setBounds(550, 150, 500, 200);
        Border borderTicket3 = BorderFactory.createLineBorder(Color.BLACK, 5);
        ticket3Outline.setBorder(borderTicket3);

        JLabel ticketLogoLabel3 = new JLabel("Etnad Airways");
        ticketLogoLabel3.setFont(new Font("Consolas", Font.BOLD, 18));
        ticketLogoLabel3.setBounds(15,10,150,35);

        JLabel passengerNameLabel3 = new JLabel("Name: " + passenger3.name);
        passengerNameLabel3.setFont(new Font("Consolas", Font.BOLD, 12));
        passengerNameLabel3.setBounds(15,40,250,35);

        JLabel flightClassLabel3 = new JLabel("Class: " + flight.flightClass1);
        flightClassLabel3.setFont(new Font("Consolas", Font.BOLD, 12));
        flightClassLabel3.setBounds(15,70,150,35);

        JLabel flyingFromLabel3 = new JLabel("From: " + flight.departingFrom1);
        flyingFromLabel3.setFont(new Font("Consolas", Font.BOLD, 12));
        flyingFromLabel3.setBounds(15,100,200,35);

        JLabel flyingToLabel3 = new JLabel("To: " + flight.departingTo1);
        flyingToLabel3.setFont(new Font("Consolas", Font.BOLD, 12));
        flyingToLabel3.setBounds(15,130,200,35);

        JLabel gender3 = new JLabel();
        gender3.setFont(new Font("Consolas", Font.BOLD, 12));
        gender3.setBounds(15,160,200,35);

        if (passenger3.gender == "Male")
        {
            gender3.setText("Gender: M");
        }
        else if (passenger3.gender == "Female")
        {
            gender3.setText("Gender: F");
        }
        else
        {
            gender3.setText("Gender: O");
        }

        JLabel adultOrChild3 = new JLabel();
        adultOrChild3.setFont(new Font("Consolas", Font.BOLD, 12));
        adultOrChild3.setBounds(400,5,200,35);

        if (passenger3.Over18)
        {
            adultOrChild3.setText("Adult Ticket");
        }
        else
        {
            adultOrChild3.setText("Child Ticket");
        }

        JLabel barCode3 = new JLabel("||| | |||| ||||||| |||");
        barCode3.setFont(new Font("Consolas", Font.BOLD, 12));
        barCode3.setBounds(330,160,300,35);

        JLabel barCode3b = new JLabel("|| ||||||||| ||||| |");
        barCode3b.setFont(new Font("Consolas", Font.BOLD, 12));
        barCode3b.setBounds(328,160,300,35);

        JLabel seatLabel3 = new JLabel("Seat: " + flight.seatSection1 + (seatNumber1+2));
        seatLabel3.setFont(new Font("Consolas", Font.BOLD, 12));
        seatLabel3.setBounds(250,40,200,35);

        JLabel departureDate3 = new JLabel("Departure date: " + flight.departureDate1);
        departureDate3.setFont(new Font("Consolas", Font.BOLD, 12));
        departureDate3.setBounds(250,70,200,35);

        //ticket 4
        JLabel subLabel4 = new JLabel(" Ticket 4:");
        subLabel4.setFont(new Font("Consolas", Font.BOLD, 18));
        subLabel4.setBounds(550, 380, 230, 35);

        JLabel ticket4Outline = new JLabel();
        ticket4Outline.setBounds(550, 420, 500, 200);
        Border borderTicket4 = BorderFactory.createLineBorder(Color.BLACK, 5);
        ticket4Outline.setBorder(borderTicket4);

        JLabel ticketLogoLabel4 = new JLabel("Etnad Airways");
        ticketLogoLabel4.setFont(new Font("Consolas", Font.BOLD, 18));
        ticketLogoLabel4.setBounds(15,10,150,35);

        JLabel passengerNameLabel4 = new JLabel("Name: " + passenger4.name);
        passengerNameLabel4.setFont(new Font("Consolas", Font.BOLD, 12));
        passengerNameLabel4.setBounds(15,40,250,35);

        JLabel flightClassLabel4 = new JLabel("Class: " + flight.flightClass1);
        flightClassLabel4.setFont(new Font("Consolas", Font.BOLD, 12));
        flightClassLabel4.setBounds(15,70,150,35);

        JLabel flyingFromLabel4 = new JLabel("From: " + flight.departingFrom1);
        flyingFromLabel4.setFont(new Font("Consolas", Font.BOLD, 12));
        flyingFromLabel4.setBounds(15,100,200,35);

        JLabel flyingToLabel4 = new JLabel("To: " + flight.departingTo1);
        flyingToLabel4.setFont(new Font("Consolas", Font.BOLD, 12));
        flyingToLabel4.setBounds(15,130,200,35);

        JLabel gender4 = new JLabel();
        gender4.setFont(new Font("Consolas", Font.BOLD, 12));
        gender4.setBounds(15,160,200,35);

        if (passenger4.gender == "Male")
        {
            gender4.setText("Gender: M");
        }
        else if (passenger4.gender == "Female")
        {
            gender4.setText("Gender: F");
        }
        else
        {
            gender4.setText("Gender: O");
        }

        JLabel adultOrChild4 = new JLabel();
        adultOrChild4.setFont(new Font("Consolas", Font.BOLD, 12));
        adultOrChild4.setBounds(400,5,200,35);

        if (passenger4.Over18)
        {
            adultOrChild4.setText("Adult Ticket");
        }
        else
        {
            adultOrChild4.setText("Child Ticket");
        }

        JLabel barCode4 = new JLabel("||||||||| |||| |||||||");
        barCode4.setFont(new Font("Consolas", Font.BOLD, 12));
        barCode4.setBounds(330,160,300,35);

        JLabel barCode4b = new JLabel("||| |||||||||||| ||| ||");
        barCode4b.setFont(new Font("Consolas", Font.BOLD, 12));
        barCode4b.setBounds(328,160,300,35);

        JLabel seatLabel4 = new JLabel("Seat: " + flight.seatSection1 + (seatNumber1+3));
        seatLabel4.setFont(new Font("Consolas", Font.BOLD, 12));
        seatLabel4.setBounds(250,40,200,35);

        JLabel departureDate4 = new JLabel("Departure date: " + flight.departureDate1);
        departureDate4.setFont(new Font("Consolas", Font.BOLD, 12));
        departureDate4.setBounds(250,70,200,35);

        //adding ticket components to each outline of the tickets

        // adding to ticket 1
        ticket1Outline.add(ticketLogoLabel1);
        ticket1Outline.add(passengerNameLabel1);
        ticket1Outline.add(flightClassLabel1);
        ticket1Outline.add(flyingFromLabel1);
        ticket1Outline.add(flyingToLabel1);
        ticket1Outline.add(adultOrChild1);
        ticket1Outline.add(gender1);
        ticket1Outline.add(barCode1);
        ticket1Outline.add(barCode1b);
        ticket1Outline.add(seatLabel1);
        ticket1Outline.add(departureDate1);

        // adding to ticket 2
        ticket2Outline.add(ticketLogoLabel2);
        ticket2Outline.add(passengerNameLabel2);
        ticket2Outline.add(flightClassLabel2);
        ticket2Outline.add(flyingFromLabel2);
        ticket2Outline.add(flyingToLabel2);
        ticket2Outline.add(adultOrChild2);
        ticket2Outline.add(gender2);
        ticket2Outline.add(barCode2);
        ticket2Outline.add(barCode2b);
        ticket2Outline.add(seatLabel2);
        ticket2Outline.add(departureDate2);

        //adding to ticket 3
        ticket3Outline.add(ticketLogoLabel3);
        ticket3Outline.add(passengerNameLabel3);
        ticket3Outline.add(flightClassLabel3);
        ticket3Outline.add(flyingFromLabel3);
        ticket3Outline.add(flyingToLabel3);
        ticket3Outline.add(adultOrChild3);
        ticket3Outline.add(gender3);
        ticket3Outline.add(barCode3);
        ticket3Outline.add(barCode3b);
        ticket3Outline.add(seatLabel3);
        ticket3Outline.add(departureDate3);

        //adding to ticket 4
        ticket4Outline.add(ticketLogoLabel4);
        ticket4Outline.add(passengerNameLabel4);
        ticket4Outline.add(flightClassLabel4);
        ticket4Outline.add(flyingFromLabel4);
        ticket4Outline.add(flyingToLabel4);
        ticket4Outline.add(adultOrChild4);
        ticket4Outline.add(gender4);
        ticket4Outline.add(barCode4);
        ticket4Outline.add(barCode4b);
        ticket4Outline.add(seatLabel4);
        ticket4Outline.add(departureDate4);

        //adding everything to panel
        panel3.add(logoLabel);
        panel3.add(titleLabel2);
        panel3.add(subLabel1);
        panel3.add(ticket1Outline);
        panel3.add(subLabel2);
        panel3.add(ticket2Outline);
        panel3.add(subLabel3);
        panel3.add(ticket3Outline);
        panel3.add(subLabel4);
        panel3.add(ticket4Outline);

        if(numberOfPassengers == 1)
        //if they only requested 1 ticket, show the first ticket
        {
            subLabel2.setVisible(false);
            subLabel3.setVisible(false);
            subLabel4.setVisible(false);
            ticket2Outline.setVisible(false);
            ticket3Outline.setVisible(false);
            ticket4Outline.setVisible(false);
        }
        else if (numberOfPassengers == 2)
        //if they requested 2, show 2
        {
            subLabel3.setVisible(false);
            subLabel4.setVisible(false);
            ticket3Outline.setVisible(false);
            ticket4Outline.setVisible(false);
        }
        else if (numberOfPassengers == 3)
        //you get the idea
        {
            subLabel4.setVisible(false);
            ticket4Outline.setVisible(false);
        }
        else
        {
            //do nothing
            System.out.println(" ");
        }

        //couldn't actually make them print the page, just here for show
        JButton print = new JButton("Print tickets");
        print.setBounds(1125,200,125,50);
        print.setFont(new Font ("Consolas", Font.BOLD, 10));
        print.addActionListener(this:: printClick);

        printSuccess = new JLabel();
        printSuccess.setBounds(1105,250,300,35);
        printSuccess.setFont(new Font ("Consolas", Font.BOLD, 10));

        JButton book = new JButton("Book flight");
        book.setBounds(1125,400,125,50);
        book.setFont(new Font ("Consolas", Font.BOLD, 10));
        book.addActionListener(this:: bookClick);

        panel3.add(print);
        panel3.add(printSuccess);
        panel3.add(book);

        frame3.setVisible(true);
    }

    public void printClick(ActionEvent e)
    {
        //basically they can print or not print
        printSuccess.setText("Sending files to nearest printer.");
    }

    public void bookClick(ActionEvent e)
    {
        //once they click book, they move on to really booking the flight
        frame3.setVisible(false);
        Frame4Creator();
    }

    //necessary variables for frame 4
    JTextField userText1;
    JTextField passwordText1;
    JButton completePayment;
    JLabel success1;

    public void Frame4Creator()
    {
        //not sure how accurate these prices are, but that's what it's supposed to be
        double economy = 1000;
        double business = 1400;
        double first = 2200;

        double ticketPrice = 0;

        if(flight.flightClass1 == "First")
        {
         ticketPrice = first;
        }
        else if(flight.flightClass1 == "Business")
        {
            ticketPrice = business;
        }
        else if (flight.flightClass1 == "Economy")
        {

            ticketPrice = economy;
        }

        double amountDue = ticketPrice * flight.numOfPassengers1;

        frame4 = new JFrame("Ticket Payment");
        frame4.setSize(500, 350);
        frame4.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //decided to give some different colors to spice it up a bit
        JPanel panel4 = new JPanel();
        panel4.setLayout(null);
        panel4.setBackground(new Color(200, 200, 100));

        JLabel amountDueLabel = new JLabel("Total due: $" + amountDue);
        amountDueLabel.setFont(new Font("Consolas", Font.BOLD, 18));
        amountDueLabel.setBounds(10, 10, 200, 35);

        JLabel userLabel1 = new JLabel("Username:");
        userLabel1.setFont(new Font("Consolas", Font.BOLD, 16));
        userLabel1.setBounds(10, 70, 80, 25);

        userText1 = new JTextField(20);
        userText1.setBounds(100, 70, 165, 25);

        JLabel passLabel1 = new JLabel("Password:");
        passLabel1.setFont(new Font("Consolas", Font.BOLD, 16));
        passLabel1.setBounds(10, 100, 80, 25);

        passwordText1 = new JPasswordField(20);
        passwordText1.setBounds(100, 100, 165, 25);

        completePayment = new JButton("Complete payment");
        completePayment.setBounds(10, 150, 200, 25);
        completePayment.setFont((new Font("Consolas", Font.BOLD, 14)));
        completePayment.addActionListener(this:: completePaymentClick);

        success1 = new JLabel(" ");
        success1.setFont(new Font("Consolas", Font.BOLD, 12));
        success1.setBounds(10, 210, 400, 25);

        frame4.add(panel4);
        panel4.add(userLabel1);
        panel4.add(userText1);
        panel4.add(passLabel1);
        panel4.add(passwordText1);
        panel4.add(completePayment);
        panel4.add(success1);
        panel4.add(amountDueLabel);

        frame4.setVisible(true);

    }

    public void completePaymentClick(ActionEvent e)
    {
        String user1 = userText1.getText();
        String password1 = passwordText1.getText();

        if (user1.equals(username) && password1.equals(passcode))
        {
            //if the password is correct
            frame4.setVisible(false);
            JOptionPane.showMessageDialog(null,"You have successfully booked and payed for your flight from " + flight.departingFrom1 +  " to " + flight.departingTo1 + "!!");
            JOptionPane.showMessageDialog(null, "Don't forget that your tickets can also be used at the " + flight.departingTo1 + " International Airport " + flight.tripLength1 + " days after departing.");
        }
        else
        {
            success1.setText("Payment failure. Enter correct account details.");
        }

    }
}


