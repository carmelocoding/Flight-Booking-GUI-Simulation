public class Flight
{
    //same thing as with passenger, but with the flight details instead.
    //Used to simplify the code when i'm trying to print flight info, all stored in one object

    String departureDate1;
    int tripLength1;
    String flightClass1;
    String departingFrom1;
    String departingTo1;
    int numOfPassengers1;
    String seatSection1;

    Flight()
    {
        departureDate1 = "##/##/####";
        tripLength1 = 0;
        flightClass1 = "Unknown";
        departingFrom1 = "Unknown";
        departingTo1 = "Unknown";
        numOfPassengers1 = 0;
        seatSection1 = "?";
    }

    Flight(String newDepartureDate, int newTripLength, String newFlightClass, String newDepartingFrom, String newDepartingTo, int newNumOfPassengers, String newSeatSection)
    {
        departureDate1 = newDepartureDate;
        tripLength1 = newTripLength;
        flightClass1 = newFlightClass;
        departingFrom1 = newDepartingFrom;
        departingTo1 = newDepartingTo;
        numOfPassengers1 = newNumOfPassengers;
        seatSection1 = newSeatSection;
    }

}
